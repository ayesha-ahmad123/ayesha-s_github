import json
import time 
import requests

from firebase import connect, send_stats


host_ip = ""
ledStatusUrl = host_ip + "/ledStatus"
connect()

while True:
    time.sleep(1)
    try:
        print("Trying to get Status", ledStatusUrl)
        resp = requests.get(ledStatusUrl)
        data_str = resp.text
        print("Status recived", data_str)
        data = json.loads(data_str)
        led1Status = data.get("led1Status")
        led2Status = data.get("led2Status")
    except Exception as e:
        print("Failed to get led status")
        print(e)
        continue

    if "on" in (led1Status, led2Status):
        stats_data = {
            "voltage": 233.7,
            "current_A": 6.6,
            "power_W": 12,
            "energy_Wh": 6,
            "frequency_Hz": 49.8,
            }
        if led1Status == "on" and led2Status == "on":
            stats_data["energy_Wh"] = 13
            stats_data["power_W"] = 24

    else:
        stats_data = {
            "voltage": 0,
            "current_A": 0.0,
            "power_W": 0.0,
            "energy_Wh": 0,
            "frequency_Hz": 0,
            }

    # Send payload to firebase 
    send_stats(stats_data)
