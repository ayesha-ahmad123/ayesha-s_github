
import time
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

def connect():
    cred = credentials.Certificate("key.json")
    firebase_admin.initialize_app(cred,
        {
            'databaseURL': 'https://pzem004-18012-default-rtdb.asia-southeast1.firebasedatabase.app'
        }
    )



def send_stats(data):

    now_timestamp = int(round(time.time() * 1000))
    print("now_timestamp: ", now_timestamp)
    ref = db.reference("/stats")
    userRef = ref.child(str(now_timestamp))

    userRef.set(data)


# stats_data = {
#             "voltage": 0,
#             "current_A": 0.0,
#             "power_W": 0.0,
#             "energy_Wh": 0,
#             "frequency_Hz": 0,
#             }

# connect()
# send_stats(stats_data)