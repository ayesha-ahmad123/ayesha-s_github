package com.iafyp.smartcontrollerfyp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class HomePage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    NavigationView navView;
    ImageView menuIcon;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        /*Button btnH, btnP, btnR, btnA;
        btnH = findViewById(R.id.btn_automation);
        btnP = findViewById(R.id.btn_prediction);
        btnA = findViewById(R.id.btn_about);*/
        navView = findViewById(R.id.navigatioView);
        menuIcon = findViewById(R.id.menuIcon);
        drawerLayout = findViewById(R.id.drawerLayout);

        navView.setNavigationItemSelectedListener(this);
        menuIcon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


        /*btnH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent openH = new Intent(
                        HomePage.this, HomeAutomation.class
                );
                startActivity(openH);

            }
        });

        btnP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent openP = new Intent(
                        HomePage.this, Predictions.class
                );
                startActivity(openP);
            }
        });


        btnA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent openA = new Intent(
                        HomePage.this, AboutApp.class
                );
                startActivity(openA);
            }
        });
        Button elect = findViewById(R.id.btn_elect);
        elect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                *//*Intent n = new Intent(
                        HomePage.this, ElectricityAnalysis.class
                );
                startActivity(n);*//*

                Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://www.google.com/"));
                startActivity(intent);

            }
        });*/
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.homeAutoMationBtn:
                Intent openH = new Intent(
                        HomePage.this, HomeAutomation.class
                );
                startActivity(openH);
                break;
            case R.id.PredictionBtn:
                Intent intentFace = new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://www.facebook.com/"));
                startActivity(intentFace);
                startActivity(intentFace);
                break;
            case R.id.AnalysisBtn:
                Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://www.google.com/"));
                startActivity(intent);
                break;

            case R.id.AboutBtn:
                Intent openAb = new Intent(
                        HomePage.this, AboutApp.class
                );
                startActivity(openAb);
                break;

        }
        return false;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (drawerLayout.isOpen()){
            drawerLayout.close();
        }else {
            onBackPressed();
        }
    }
}